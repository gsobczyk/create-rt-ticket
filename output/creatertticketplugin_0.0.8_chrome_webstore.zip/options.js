KangoAPI.onReady(function() {
  initOptionsTree();
});

