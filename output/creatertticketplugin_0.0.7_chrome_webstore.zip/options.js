KangoAPI.onReady(function() {
  initOptionsTree();
});

